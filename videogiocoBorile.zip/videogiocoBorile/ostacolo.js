class Ostacolo{
    constructor (y, speed){
        this.r = 100;
        this.x = 1200;
        this.y = y - this.r;
        this.speed = speed;
    }

    show() {
        image(oImg, this.x, this.y, this.r, this.r);
    }

    update() {    //quando l'ostacolo esce dallo schermo di gioco viene eliminato
        this.x -=10;
        if (this.x < -100) {
          // Remove enemies that go off-screen
          ostacoli.splice(ostacoli.indexOf(this), 1);
        }
      }
      
}