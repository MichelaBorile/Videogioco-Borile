class Player{
    constructor(){
        this.x = 400;
        this.r = 150;
        this.y = pHeight - this.r;
        this.speed = 5;

    }
    
    show(pImg) {
        image(pImg, this.x, this.y, this.r, this.r);  
    }
    hits(ostacolo){   //funzione che controlla la collisione
      let x1 = this.x + this.r *0.5;
      let y1 = this.y + this.r *0.5;
      let x2 = ostacolo.x + ostacolo.r * 0.5;
      let y2 = ostacolo.y + ostacolo.r *0.5;

      return collideCircleCircle(x1, y1, this.r, x2, y2, ostacolo.r);
    }
    move() {    //funzione che fa muovere l'omino con le frecce
        if (keyIsDown(LEFT_ARROW)) {
          this.x-= this.speed;
        }
        if (keyIsDown(RIGHT_ARROW)) {
          this.x+= this.speed;
        }
        if (keyIsDown(UP_ARROW)) {
          this.y-= this.speed;
        }
        if (keyIsDown(DOWN_ARROW)) {
          this.y+= this.speed;
        }

        this.y = constrain(this.y, 0, height-this.r);

      }
}