let sfondoIniziale;
let sfondo1;

let schermata  = 0;

let punteggio=0;
let width = 1295
let height = 592
let x = 100;
let y = 100;
let nframe;

//player
let pImg1;
let pImg2;
let pImg3;
let player;
let pHeight = 350;
let immune=false;
let immuneDuration = 1800 //durata immunità in frame

//ostacolo
let ostacoli = [];
let oImg;


let x1 = 0;
let x2;
let scrollSpeed =2;

let vite = 3;
let vita = [];
let v;


let level =0;
let prevPunti =0;
let liv =0;

function preload() {
    sfondoIniziale = loadImage('img/start.jpg');
    sfondo1 = loadImage('img/sfondo1.jpg');
    sfondo2 = loadImage('img/sfondo2.jpg');
    sfondo3 = loadImage('img/sfondo3.jpg');
    pImg1 = loadImage('img/lolly.png');
    pImg2 = loadImage('img/molly.png');
    pImg3 = loadImage('img/dolly.png')
    oImg = loadImage ('img/mojoJojo.png');
    gameOver = loadImage ('img/gameOver.jpg');
    vittoria = loadImage('img/level.jpg');
    fine = loadImage('img/fine.jpg');
    v = loadImage('img/vita.png')
}

function setup(){
    createCanvas(width, height);
    background (sfondoIniziale);
    player = new Player();      //creazione player
    for (let i = 0; i < 5; i++) {   //creazione ostacoli
        ostacoli.push(new Ostacolo(random(100, 400), 1));  //passo all'array una posizione causale tra 100 e 400
    }
    for (let i =0; i<vite; i++){
        vita.push(v);
    }
    x2=width;
}

function draw(){    //gestione schermate
    if (schermata == 0){
        screen0();
    }else if(schermata==1){
        screen1();        
    }else if(schermata ==2){
        screen2();
    }else if(schermata ==3){
        screen3();
    }else if(schermata==4){
        screen4(level);
    }  
}
function screen0(){     //pagina iniziale 
    punteggio=0;
    prevPunti =0;
    ostacoli.pop();
    vite =3;
    level=0;
    liv=0;
    background(sfondoIniziale);
}
function screen1(){     //schermata di gioco, in base al livello cambia sfondo e personaggio, essendo 3 i personaggi ogni 3 ricomincia
    prevPunti ++;   //contatore temporaneo dei punti, si azzera ogni 3 livelli per permette il cambio infinito tra i livelli --> ogni 1000 punti si supera il livello
    if(level == 0){
        if (prevPunti < 1000){
            livello(sfondo1, pImg1);        //chiama funzione livello in cui si gestisce il gioco effettivo
        }
        else{
            level=1;        
            schermata=4;    //setta la schermata che dice all'utente che ha superato il livello
            liv++;
        }
    }else if(level==1){
        if (prevPunti < 2000){
            livello(sfondo2, pImg2);
        }
        else{
            level=2;
            schermata=4;
            liv++;
        }
    }else if(level==2){
        if(prevPunti < 3000){
            livello(sfondo3, pImg3);
        }else{
            level=3;
            schermata=4;
            liv++
        }
        
    }else{
        level=0;    //quando il contatore dei punteggi temporaneo supera i 3000, faccio ripartire il level da 0 in modo da non far mai bloccare il gioco e renderlo più dinamico
        prevPunti=0;    //quindi si azzera anche il contatore temporaneo che ricomincia
    }
    
}
function screen2(){     //schermata game over, il giocatore ha 3 vite, per cui quando perde ma ha ancora delle vite gli compare questa schermata in cui può decidere se uscire dal gioco, ricominciare da capo o resuscitare perdendo una vita
    background(gameOver);
    fill(0, 0, 255);
    rect(390, 400, 100, 40);
    fill(255);
    textSize(18);
    text("Resuscita", 400, 425);

    fill(0, 0, 255);
    rect(590, 400, 100, 40);
    fill(255);
    textSize(18);
    text("Ricomincia", 595, 425);

    fill(0, 0, 255);
    rect(790, 400, 100, 40);
    fill(255);
    textSize(18);
    text("Esci", 820, 425);
}
function screen3(){     //schermata finale, quando non si hanno più vite o l'utente decide di uscire dal gioco, qui gli vengono stampati punteggio e livello raggiunto
    background(fine);
    fill(255);
    textFont("Comic Sans MS")
    textSize(30);
    text("punteggio: " + punteggio, 550, 520);
    fill(255);
    textFont("Comic Sans MS")
    textSize(30);
    text("livello: " + liv, 550, 570);
}
function screen4(){     //schermata superamento livello, quando si supera un livello, l'utente vedrà a video a che punto è del gioco (punteggio e livello) e potrà scegliere se continuare a giocare o uscire
    background(vittoria);

    fill(0, 128, 0);
    rect(390, 400, 100, 40);
    fill(255);
    textSize(18);
    text("Continua", 395, 425);

    fill(0, 128, 0);
    rect(590, 400, 100, 40);
    fill(255);
    textSize(18);
    text("Stop", 620, 425);

    fill(255);
    textFont("Comic Sans MS")
    textSize(30);
    text("punteggio: " + punteggio, 900, 420);
    fill(255);
    textFont("Comic Sans MS")
    textSize(30);
    text("livello: " + liv, 900, 460);

}
function livello(sfondo, pImg){     //gestione del gioco effettivo
    let xV = 1000;
    let yV = 80;
    scrolling(sfondo);  //sfondo che scorre
    // fill(255);
    // textSize(16);
    // text("VITE: " + vite, 100, 100);
    for (let i=0; i<vite;i++){      //disegno le vite a schermo
        image(vita[i], xV, yV, 50, 50);
        xV+= 50;
    } 
    if (random(1)<0.010){       //apparizione ostacoli in modo randomico, ogni tot livelli la difficoltà aumenta aumentando la velocità dell'ostacolo
        if(liv<=5){
            ostacoli.push(new Ostacolo(random(100, 500), 1));
        }else if(liv>5 && liv< 15){
            ostacoli.push(new Ostacolo(random(100, 500), 10));
        }else{
            ostacoli.push(new Ostacolo(random(100, 500), 15));
        }
    }
        
    for (let enemy of ostacoli) {
        enemy.update();
        enemy.show();
        if (player.hits(enemy)){        //gestione collissione tra omino e ostacolo
            if (vite > 0){
                schermata =2;      
            }else{
                schermata=3;
            }     
        }else{
            punteggio++;        //se non c'è collissione il punteggio si incrementa
        }
    }
    if (immune){        //quando si decide di resuscitare si è immuni per qualche secondo
        if(frameCount %30 <15){ //Cambia ogni mezzo secondo (30 frame), fa lampeggiare il giocatore ogni mezzo secondo durante l’immunità.
            player.show(pImg);
        }    
    }else{
        player.show(pImg);
    }
    player.move();
   
}
function mousePressed(){        //gestione vari pulsanti tramite mousePressed

    if (mousePressed && mouseX > 565 && mouseX < 725 && mouseY > 360 && mouseY < 414){      //start game
        if (schermata == 0){
            schermata = 1;
        }
    }else if (mousePressed && mouseX>390 && mouseX <490 && mouseY > 400 && mouseY < 440){
        if(schermata == 2){     //resuscita
            ostacoli.pop();
            revivePlayer();
            vite--;
            schermata = 1;
        }else if(schermata==4){     //continua dopo aver superato il livello
            ostacoli.pop();
            schermata=1;
        }
    }else if(mousePressed && mouseX > 590 && mouseX < 690 && mouseY > 400 && mouseY < 440){
        if (schermata ==2){     //ricomincia dopo aver perso 
            ostacoli.pop();
            vite =3;
            punteggio =0;
            level=0;
            prevPunti=0;
            schermata =1;
        }else if(schermata == 4){   //esce dal gioco dopo aver superato il livello
            schermata = 3;
        }
    }else if(mousePressed && mouseX > 790 && mouseX<890 && mouseY>400 && mouseY< 440){
        if(schermata ==2){  //esce quando ha perso 
            schermata = 3;
        }
        
    }else if(mousePressed && mouseX> 467 && mouseX<612 && mouseY > 425 && mouseY < 460){
        if(schermata == 3){ //se clicca yes, al vuoi giocare di nuovo nella schermata finale 
            vite =3;
            punteggio = 0;
            level = 0;
            liv =0;
            prevPunti = 0;
            ostacoli.pop();
            schermata =1;
        }
    }else if(mousePressed && mouseX> 677 && mouseX<822 && mouseY > 425 && mouseY < 460){
        if (schermata == 3){    //se clicca no, al vuoi giocare di nuovo nella schermata finale
            level =0;
            liv=0;
            schermata =0;
        }
    }
    
}
function scrolling(sfondo){     //scrolling sfondo
    image(sfondo, x1, 0, width, height);
    image(sfondo, x2, 0, width, height);
    x1 -= scrollSpeed;
    x2-=scrollSpeed;

    if(x1< -width) {
        x1=width;
    }
    if(x2< -width){
        x2=width;
    }
    
}
function revivePlayer(){        //gestione immunità
    immune = true;
    setTimeout(()=>{
        immune = false;
    }, immuneDuration);
}
//movimento sfondo --> scrolling background libreria p5
//p5 js, ml 
//su p5 js cerco le librerie a disposizione con le funzioni